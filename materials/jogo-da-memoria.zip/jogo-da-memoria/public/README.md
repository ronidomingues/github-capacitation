# Documentação Pública

Este diretório contém arquivos públicos que podem ser referenciados externamente.

## Sobre o Jogo

O Jogo da Memória de Frutas é um projeto educativo desenvolvido para demonstrar conceitos de desenvolvimento web e uso do GitHub Pages.

### Características Técnicas

- **Design Responsivo**: Adapta-se a diferentes tamanhos de tela
- **Performance**: Código otimizado para carregamento rápido
- **Acessibilidade**: Interface amigável e intuitiva
- **Cross-browser**: Compatível com os principais navegadores

### Recursos Utilizados

- Gradientes CSS para efeitos visuais
- Grid Layout para organização das cartas
- Transformações CSS para animações
- jQuery para manipulação do DOM
- AJAX para demonstração de requisições assíncronas

---

*Projeto educativo - Desenvolvido para capacitação em GitHub*
