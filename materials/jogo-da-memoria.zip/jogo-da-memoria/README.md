# Jogo da Memória - Frutas

Um jogo da memória simples e divertido com tema de frutas, desenvolvido para demonstração de GitHub Pages.

## 🎮 Como Jogar

1. Clique nas cartas para virá-las
2. Encontre os pares de frutas iguais
3. Complete o jogo no menor tempo e com o menor número de tentativas

## 🛠️ Tecnologias Utilizadas

- HTML5
- CSS3
- JavaScript
- jQuery
- AJAX

## 📁 Estrutura do Projeto

```bash
/jogo-da-memoria/
├── index.html
├── LICENSE
├── public
│   └── README.md
├── README.md
└── src
    ├── assets
    │   └── images
    ├── css
    │   └── style.css
    └── js
        ├── game.js
        └── utils.js
```

## 🚀 Como Executar

1. Faça o download ou clone o projeto
2. Abra o arquivo `index.html` em seu navegador
3. Ou acesse via GitHub Pages: [link-do-seu-repositorio]

## 📝 Funcionalidades

- Interface responsiva
- Contador de tempo
- Contador de tentativas
- Sistema de dicas com AJAX
- Animações suaves
- Tela de vitória com estatísticas

## 🎯 Objetivo Educacional

Este projeto foi desenvolvido para fins educacionais, demonstrando:
- Uso de GitHub Pages
- Organização de projetos web
- Separação de responsabilidades (HTML, CSS, JS)
- Uso de jQuery e AJAX
