// Lógica principal do jogo
$(document).ready(function() {
    // Variáveis do jogo
    let cards = [];
    let flippedCards = [];
    let matchedPairs = 0;
    let attempts = 0;
    let timer = 0;
    let timerInterval;
    let gameStarted = false;
    let canFlip = true;

    // Emojis de frutas
    const fruits = ['🍎', '🍌', '🍒', '🍇', '🍊', '🍓', '🍑', '🥭'];
    
    // Inicializar o jogo
    function initGame() {
        // Resetar variáveis
        cards = [];
        flippedCards = [];
        matchedPairs = 0;
        attempts = 0;
        timer = 0;
        gameStarted = false;
        canFlip = true;
        
        // Atualizar UI
        $('#attempts').text('0');
        $('#pairs').text('0/8');
        $('#timer').text('0s');
        
        // Parar timer anterior se existir
        if (timerInterval) {
            clearInterval(timerInterval);
        }
        
        // Criar pares de cartas
        let cardValues = [...fruits, ...fruits];
        
        // Embaralhar as cartas
        cardValues = window.gameUtils.shuffleArray(cardValues);
        
        // Limpar tabuleiro
        $('#game-board').empty();
        
        // Criar cartas no tabuleiro
        cardValues.forEach((value, index) => {
            const card = $('<div>')
                .addClass('card')
                .attr('data-index', index)
                .attr('data-value', value)
                .append(
                    $('<div>').addClass('card-front').text(value),
                    $('<div>').addClass('card-back').text('?')
                );
            
            $('#game-board').append(card);
            
            // Adicionar evento de clique
            card.on('click', handleCardClick);
        });
        
        // Esconder mensagem de vitória
        $('#win-message').removeClass('show');
    }
    
    // Manipular clique na carta
    function handleCardClick() {
        if (!canFlip) return;
        
        const card = $(this);
        
        // Não permitir virar a mesma carta duas vezes
        if (card.hasClass('flipped') || flippedCards.includes(card)) {
            return;
        }
        
        // Iniciar o jogo e o timer na primeira jogada
        if (!gameStarted) {
            startGame();
        }
        
        // Virar a carta
        card.addClass('flipped');
        flippedCards.push(card);
        
        // Verificar se temos duas cartas viradas
        if (flippedCards.length === 2) {
            canFlip = false;
            attempts++;
            $('#attempts').text(attempts);
            
            // Verificar se as cartas são iguais
            const card1 = flippedCards[0];
            const card2 = flippedCards[1];
            
            if (card1.attr('data-value') === card2.attr('data-value')) {
                // Par encontrado
                matchedPairs++;
                $('#pairs').text(`${matchedPairs}/8`);
                
                // Remover eventos de clique das cartas correspondentes
                card1.off('click');
                card2.off('click');
                
                flippedCards = [];
                canFlip = true;
                
                // Verificar se o jogo terminou
                if (matchedPairs === 8) {
                    endGame();
                }
            } else {
                // Par não encontrado, virar as cartas de volta após um tempo
                setTimeout(() => {
                    card1.removeClass('flipped');
                    card2.removeClass('flipped');
                    flippedCards = [];
                    canFlip = true;
                }, 1000);
            }
        }
    }
    
    // Iniciar o jogo
    function startGame() {
        gameStarted = true;
        timerInterval = setInterval(() => {
            timer++;
            $('#timer').text(`${window.gameUtils.formatTime(timer)}`);
        }, 1000);
    }
    
    // Finalizar o jogo
    function endGame() {
        clearInterval(timerInterval);
        
        // Mostrar mensagem de vitória
        $('#final-stats').html(`
            <p>Tentativas: ${attempts}</p>
            <p>Tempo: ${window.gameUtils.formatTime(timer)}</p>
        `);
        $('#win-message').addClass('show');
    }
    
    // Função de dica usando AJAX
    function getHint() {
        // Simular uma requisição AJAX
        $.ajax({
            url: 'https://jsonplaceholder.typicode.com/posts/1',
            method: 'GET',
            success: function(data) {
                // Esta é uma simulação, já que a API não retorna dicas reais
                // Em um caso real, você teria um endpoint que retorna uma dica
                
                // Encontrar um par não descoberto para dar dica
                const unflippedCards = $('.card:not(.flipped)');
                if (unflippedCards.length > 0) {
                    // Escolher uma carta aleatória para mostrar brevemente
                    const randomIndex = Math.floor(Math.random() * unflippedCards.length);
                    const hintCard = $(unflippedCards[randomIndex]);
                    
                    // Mostrar a carta brevemente
                    hintCard.addClass('flipped');
                    setTimeout(() => {
                        hintCard.removeClass('flipped');
                    }, 1000);
                    
                    alert('Dica: Preste atenção nesta carta!');
                } else {
                    alert('Todas as cartas já foram viradas!');
                }
            },
            error: function() {
                alert('Erro ao obter dica. Tente novamente.');
            }
        });
    }
    
    // Event Listeners
    $('#restart-btn').on('click', initGame);
    $('#play-again-btn').on('click', initGame);
    $('#hint-btn').on('click', getHint);
    
    // Inicializar o jogo quando a página carregar
    initGame();
});